# Curso-Arduino-Proyectos
Repositorio Curso Arduino Proyectos

![imagen](/ejemplo%20fritzing/contador%20pulsos_bb.png)
